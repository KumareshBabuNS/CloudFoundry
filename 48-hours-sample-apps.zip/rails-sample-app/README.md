# Rails Sample App

```cf push```

https://docs.cloudfoundry.org/buildpacks/ruby/ruby-tips.html
