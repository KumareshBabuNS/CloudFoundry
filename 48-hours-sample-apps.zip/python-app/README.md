Python Cloud Foundry Example
=============================

Can be deployed to a Cloud Foundry instance with

$ cf push
